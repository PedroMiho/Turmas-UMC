package com.example.FinanERP;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FinanErpApplication {

	public static void main(String[] args) {
		SpringApplication.run(FinanErpApplication.class, args);
	}

}
