package com.example.FinanERP.model;

public enum Tipo {
    ENTRADA,
    SAIDA
}
