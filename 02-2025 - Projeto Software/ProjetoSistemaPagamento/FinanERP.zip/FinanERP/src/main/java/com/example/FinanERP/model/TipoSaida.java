package com.example.FinanERP.model;

public enum TipoSaida {
    ALUGUEL,
    ENERGIA,
    AGUA,
    INTERNET,
    MATERIAIS
}
